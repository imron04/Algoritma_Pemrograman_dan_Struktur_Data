#include <stdio.h>
#include <conio.h>

using namespace std;
int main() {
//	int a = 3, b = 2, c = 1, bil;
//	printf("Bil-A | Bil-B | Bil-C\n");
//	printf("----------------------------");
//	for (bil =1; bil <= 10; ++bil) {
//		a +=b, b += c, c += 2;
//		printf("\n%d\t| %d\t| %d", a,b,c);
//		if(c == 13) {
//			break;
//		}
//	}
//	getche();

//	int x, bil = 0; 								// Membuat 2 Variabel, yaitu 'x' dan 'bil' yang bernilai 0  
//	cout << "Masukkan Bilangan Pembatas Akhir : "; 	// Menampilkan "Masukkan Bilangan Pembatas Akhir : " ke layar
//	cin >> x; 										// Mengambil input-an yang diketik lalu disimpan ke variabel x
//	
//	do 								// Menjalankan kode yang ada didalam kurung kurawal sekali
//		{ 							// Kurung kurawal pembuka do
//			if (bil >= x) 			// Jika nilai bil lebih besar atau sama dengan nilai x, jalankan kode dibawah
//				{						// Kurung kurawal pembuka if
//					break;				// Menghentikan program
//					cout << bil << " "; // Menampilkan nilai bil dan spasi 
//				}						// Kurung kurawal penutup if
//		} 							// Kurung kurawal penutup do
//	while (bil+=4);					// Nilai bil ditambah 4 lalu mengulang kode do  
//	getchar();						// Mengambil 1 karakter yang diinputkan
	
	
}
