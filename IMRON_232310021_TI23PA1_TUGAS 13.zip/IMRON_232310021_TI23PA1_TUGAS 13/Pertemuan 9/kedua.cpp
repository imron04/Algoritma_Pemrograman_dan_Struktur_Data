#include <iostream>
using namespace std;


void garis() {
	cout << "------------------------";
}

int main() {
	garis();
}
