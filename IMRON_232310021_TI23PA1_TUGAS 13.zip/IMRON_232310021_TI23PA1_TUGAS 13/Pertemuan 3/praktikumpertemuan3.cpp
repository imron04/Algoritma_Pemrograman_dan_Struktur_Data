#include <iostream>
using namespace std;
// Praktikum Prtemuan 3
int main() {
//	float pendapatan, jasa=0, komisi=0, total=0;
//	cout<<"Pendapatan Hari ini Rp. : ";
//	cin>>pendapatan;
//	
//	if(pendapatan >= 0 && pendapatan <= 200000){
//		jasa = 10000;
//		komisi=0.1 * pendapatan;
//	} else {
//		if (pendapatan <= 500000){
//			jasa = 20000;
//			komisi = 0.15 * pendapatan;
//		} else {
//			jasa = 30000;
//			komisi = 0.2 * pendapatan;
//		}
//	}
//	
//	/* menghitung total */
//	total = komisi+jasa;
//	cout<<"\nUang Jasa = Rp."<<jasa;
//	cout<<"\nUang Komisi = Rp."<<komisi;
//	cout<<"\n==============\n";
//	cout<<"Hasil Total = Rp."<<total;
//	getchar();

//	char kode;
//	cout<<"Masukkan Kode Barang (A, B, C) : ";
//	cin>>kode;
//	
//	switch(kode){
//		case 'A' :
//			cout<<"Alat Olahraga";
//			break;
//		case 'B' :
//			cout<<"Alat Elektronik";
//			break;
//		case 'C' :
//			cout<<"Alat Musik";
//			break;
//		default :
//			cout<<"Anda salah memasukkan kode";
//			break;	
//	}
//	getchar();

//	double total_beli, potongan = 0, jum_bayar = 0;
//	cout<<"Total Beli = Rp. ";
//	cin>>total_beli;
//	
//	if(total_beli >= 50000) {
//		potongan = 0.2 * total_beli;
//		cout<<"Besarnya Potongan = "<<potongan;
//	}
//		jum_bayar = total_beli - potongan;
//		cout<<"\nJumlah yang harus dibayarkan Rp. "<<jum_bayar;
//		getchar();
	
}
