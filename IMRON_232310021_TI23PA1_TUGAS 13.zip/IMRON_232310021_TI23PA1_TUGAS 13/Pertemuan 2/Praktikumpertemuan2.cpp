#include <iostream>
using namespace std;

int main(){
//	int a,b,c = 0, d=0;
//	cout<<"Masukkan A : ";
//	cin>>a;
//	
//	cout<<"\n Masukkan B : ";
//	cin>>b;
//	
//	d = a *b;
//	cout<<"Hasil dari A * b = "<<d;
//	getchar();

// Soal 2

int x,y,tambah,kurang,kali,bagi;
cout<<"Masukkan bilangan 1 : ";
cin>>x;

cout<<"\nMasukkan Bilangan 2 : ";
cin>>y;

tambah=x+y;
kurang=x-y;
kali=x*y;
bagi=x/y;

cout<<"\nHasil Tambah = "<<tambah;
cout<<"\nHasil Kurang = "<<kurang;
cout<<"\nHasil Kali = "<<kali;
cout<<"\nHasil Bagi = "<<bagi;
return 0;
}

// Buatlah program menghitung luas lingkaran 2 soal dan volume tabung 2 soal menggunakan c++
